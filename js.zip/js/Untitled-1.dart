// Définition des constantes pour les dimensions du canvas et la taille de la bordure
const canvasWidth = 1570;
const canvasHeight = 700;
const borderSize = 5;
const roadWidth = 75; // Largeur de la route

// Création d'un canvas
const canvas = document.createElement('canvas');
canvas.width = canvasWidth;
canvas.height = canvasHeight;
document.body.appendChild(canvas);

// Récupération du contexte 2D du canvas
const ctx = canvas.getContext('2d');

// Définition des variables pour la position du point rouge
let redPointX = canvasWidth / 2; // Position initiale X du point au centre du canvas
let redPointY = canvasHeight / 2; // Position initiale Y du point au centre du canvas

// Fonction pour dessiner le point rouge et la route
function drawRedPoint() {
    // Dessiner la route
    ctx.clearRect(0, 0, canvasWidth, canvasHeight); // Effacer le canvas
    ctx.fillStyle = 'gray';
    ctx.fillRect(0, (canvasHeight - roadWidth) / 120, canvasWidth, roadWidth); // Route horizontale au centre du canvas
    ctx.fillRect(0, (canvasHeight - roadWidth) / 1, canvasWidth, roadWidth); // Route horizontale au centr
    
    // Dessiner les bordures noires
    ctx.fillStyle = 'black';
    ctx.fillRect(0, 0, canvasWidth, borderSize); // Bordure supérieure
    ctx.fillRect(0, 0, borderSize, canvasHeight); // Bordure gauche
    ctx.fillRect(canvasWidth - borderSize, 0, borderSize, canvasHeight); // Bordure droite
    ctx.fillRect(0, canvasHeight - borderSize, canvasWidth, borderSize); // Bordure inférieure
    // Dessiner le point rouge
    ctx.beginPath();
    ctx.arc(redPointX, redPointY, 10, 0, Math.PI * 2);
    ctx.fillStyle = 'blue';
    ctx.fill();
}

// Fonction de mise à jour de la position du point rouge en fonction des touches de direction
function updateRedPointPosition(event) {
    const speed = 13; // Vitesse de déplacement du point rouge
    switch (event.keyCode) {
        case 37: // Flèche gauche
            redPointX = Math.max(redPointX - speed, borderSize); // Limiter la position pour éviter les bordures
            break;
        case 38: // Flèche haut
            redPointY = Math.max(redPointY - speed, borderSize); // Limiter la position pour éviter les bordures
            break;
        case 39: // Flèche droite
            redPointX = Math.min(redPointX + speed, canvasWidth - borderSize); // Limiter la position pour éviter les bordures
            break;
        case 40: // Flèche bas
            redPointY = Math.min(redPointY + speed, canvasHeight - borderSize); // Limiter la position pour éviter les bordures
            break;
    }
    drawRedPoint(); // Redessiner le point rouge après avoir mis à jour sa position
}

// Écouter les événements de pression des touches de direction
window.addEventListener('keydown', updateRedPointPosition);

// Appeler drawRedPoint() pour dessiner le point rouge au chargement de la page
drawRedPoint();
