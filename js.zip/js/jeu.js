// Définition des constantes pour les dimensions du canvas et la taille de la bordure
const canvasWidth = 3000;
const canvasHeight = 1500;
const borderSize = 10;
const roadWidth = 75; // Largeur de la route

// Création d'un canvas
const canvas = document.createElement('canvas');
canvas.width = canvasWidth;
canvas.height = canvasHeight;
document.body.appendChild(canvas);

// Récupération du contexte 2D du canvas
const ctx = canvas.getContext('2d');

// Définition des variables pour la position du point rouge
let redPointX = canvasWidth / 2; // Position initiale X du point au centre du canvas
let redPointY = canvasHeight / 25; // Position initiale Y du point au centre du canvas

// Définition des variables pour la position du point bleu
let bluePointX = canvasWidth / 2; // Position initiale X du point au centre du canvas
let bluePointY = canvasHeight / 25 // Position initiale Y du point au centre du canvas

// Définir la variable pour stocker la direction actuelle du point rouge
let currentRedDirection = null;

// Définir la variable pour stocker la direction actuelle du point bleu
let currentBlueDirection = null;

// Fonction pour dessiner les points et la route
function drawPoints() {
    // Dessiner la route horizontale
    ctx.clearRect(0, 0, canvasWidth, canvasHeight); // Effacer le canvas
    ctx.fillStyle = 'gray';
//
    // Nouvelle longueur de la route
var nouvelleLongueur = 500; // Remplacez 500 par la nouvelle longueur souhaitée en pixels

// Dessiner la route avec la nouvelle longueur
ctx.fillRect(0, (canvasHeight - roadWidth) / 1, nouvelleLongueur, roadWidth);



//

    ctx.fillRect(0, (canvasHeight - roadWidth) / 120, canvasWidth, roadWidth); // Route horizontale au centre du canvas
    ctx.fillStyle = 'blue';
    ctx.fillRect((canvasWidth - roadWidth) / 2, 0, 10 , 85); // Route verticale au centre du canvas
    
    // Dessiner la route verticale
    ctx.fillStyle = 'gray'; 
    ctx.fillRect((canvasWidth - roadWidth) / 300, 0, roadWidth, canvasHeight); // Route verticale au centre du canvas
    ctx.fillRect((canvasWidth - roadWidth) / 1, 0, roadWidth, canvasHeight); // Route verticale au centre du canvas
    
    // Nouvelle longueur de la route verticale
var nouvelleLongueurVerticale = 1500; // Remplacez 400 par la nouvelle longueur souhaitée en pixels

// Dessiner la route verticale avec la nouvelle longueur
ctx.fillRect((canvasWidth - roadWidth) / 6, 0, roadWidth, nouvelleLongueurVerticale);


    // Dessiner les bordures noires
    ctx.fillStyle = 'black';
    ctx.fillRect(0, 0, canvasWidth, borderSize); // Bordure supérieure
    ctx.fillRect(0, 0, borderSize, canvasHeight); // Bordure gauche
    ctx.fillRect(canvasWidth - borderSize, 0, borderSize, canvasHeight); // Bordure droite
    ctx.fillRect(0, canvasHeight - borderSize, canvasWidth, borderSize); // Bordure inférieure

    // Dessiner le point rouge
    ctx.beginPath();
    ctx.arc(redPointX, redPointY, 10, 0, Math.PI * 2);
    ctx.fillStyle = 'red';
    ctx.fill();

    // Dessiner le point bleu
    ctx.beginPath();
    ctx.arc(bluePointX, bluePointY, 10, 0, Math.PI * 2);
    ctx.fillStyle = 'blue';
    ctx.fill();
}

// Fonction de mise à jour de la position du point rouge en fonction des touches de direction
function updateRedPointPosition(event) {
    const speed = 30; // Vitesse de déplacement du point rouge
    switch (event.key) {
        case 'z': // Touche Z (haut)
            currentRedDirection = 'up';
            break;
        case 'q': // Touche Q (gauche)
            currentRedDirection = 'left';
            break;
        case 's': // Touche S (bas)
            currentRedDirection = 'down';
            break;
        case 'd': // Touche D (droite)
            currentRedDirection = 'right';
            break;
    }
}

// Fonction de mise à jour de la position du point bleu en fonction des touches de direction
function updateBluePointPosition(event) {
    const speed = 30; // Vitesse de déplacement du point bleu
    switch (event.key) {
        case 'ArrowUp': // Flèche vers le haut
            currentBlueDirection = 'up';
            break;
        case 'ArrowLeft': // Flèche vers la gauche
            currentBlueDirection = 'left';
            break;
        case 'ArrowDown': // Flèche vers le bas
            currentBlueDirection = 'down';
            break;
        case 'ArrowRight': // Flèche vers la droite
            currentBlueDirection = 'right';
            break;
    }
}

// Créer une fonction pour déplacer le point rouge selon la direction actuelle
function moveRedPoint() {
    const speed = 20; // Vitesse de déplacement du point rouge
    switch (currentRedDirection) {
        case 'left':
            redPointX = Math.max(redPointX - speed, borderSize); // Limiter la position pour éviter les bordures
            break;
        case 'up':
            redPointY = Math.max(redPointY - speed, borderSize); // Limiter la position pour éviter les bordures
            break;
        case 'right':
            redPointX = Math.min(redPointX + speed, canvasWidth - borderSize); // Limiter la position pour éviter les bordures
            break;
        case 'down':
            redPointY = Math.min(redPointY + speed, canvasHeight - borderSize); // Limiter la position pour éviter les bordures
            break;
    }
    drawPoints(); // Redessiner les points après avoir mis à jour leur position
}

// Créer une fonction pour déplacer le point bleu selon la direction actuelle
function moveBluePoint() {
    const speed = 20; // Vitesse de déplacement du point bleu
    switch (currentBlueDirection) {
        case 'left':
            bluePointX = Math.max(bluePointX - speed, borderSize); // Limiter la position pour éviter les bordures
            break;
        case 'up':
            bluePointY = Math.max(bluePointY - speed, borderSize); // Limiter la position pour éviter les bordures
            break;
        case 'right':
            bluePointX = Math.min(bluePointX + speed, canvasWidth - borderSize); // Limiter la position pour éviter les bordures
            break;
        case 'down':
            bluePointY = Math.min(bluePointY + speed, canvasHeight - borderSize); // Limiter la position pour éviter les bordures
            break;
    }
    drawPoints(); // Redessiner les points après avoir mis à jour leur position
}


// Appeler drawPoints() pour dessiner les points au chargement de la page
drawPoints();

// Écouter les événements de pression des touches de direction pour les deux points
window.addEventListener('keydown', updateRedPointPosition);
window.addEventListener('keydown', updateBluePointPosition);

// Appeler moveRedPoint toutes les 50 millisecondes pour déplacer le point rouge automatiquement
setInterval(moveRedPoint, 50);

// Appeler moveBluePoint toutes les 50 millisecondes pour déplacer le point bleu automatiquement
setInterval(moveBluePoint, 50);
